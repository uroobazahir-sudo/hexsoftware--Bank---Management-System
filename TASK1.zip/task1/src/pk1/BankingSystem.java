package pk1;
import java.util.Scanner;
public class BankingSystem {
	    public static void main(String[] args) {

	        Scanner sc = new Scanner(System.in);

	        System.out.print("Enter Customer Name: ");
	        String name = sc.nextLine();

	        System.out.print("Enter Account Number: ");
	        int accNo = sc.nextInt();

	        System.out.print("Enter Initial Balance: ");
	        double balance = sc.nextDouble();

	        BankAccount account = new BankAccount(accNo, balance);
	        Customer customer = new Customer(name, account);

	        int choice;

	        do {
	            System.out.println("\n===== Banking Menu =====");
	            System.out.println("1. Deposit");
	            System.out.println("2. Withdraw");
	            System.out.println("3. Check Balance");
	            System.out.println("4. Customer Details");
	            System.out.println("5. Exit");
	            System.out.print("Enter Choice: ");

	            choice = sc.nextInt();

	            switch (choice) {
	                case 1:
	                    System.out.print("Enter Amount to Deposit: ");
	                    double dep = sc.nextDouble();
	                    account.deposit(dep);
	                    break;

	                case 2:
	                    System.out.print("Enter Amount to Withdraw: ");
	                    double wd = sc.nextDouble();
	                    account.withdraw(wd);
	                    break;

	                case 3:
	                    System.out.println("Current Balance: " + account.getBalance());
	                    break;

	                case 4:
	                    customer.displayInfo();
	                    break;

	                case 5:
	                    System.out.println("Thank You!");
	                    break;

	                default:
	                    System.out.println("Invalid Choice!");
	            }

	        } while (choice != 5);

	        sc.close();
	    }
	}

